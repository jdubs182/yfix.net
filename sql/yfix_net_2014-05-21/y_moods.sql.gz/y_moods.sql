
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `y_moods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `y_moods` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `active` enum('1','0') NOT NULL DEFAULT '1',
  `locale` char(7) NOT NULL DEFAULT 'en',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `y_moods` WRITE;
/*!40000 ALTER TABLE `y_moods` DISABLE KEYS */;
INSERT INTO `y_moods` VALUES (1,'','1','en'),(2,'None, or other','1','en'),(3,'accomplished','1','en'),(4,'aggravated','1','en'),(5,'amused','1','en'),(6,'angry','1','en'),(7,'annoyed','1','en'),(8,'anxious','1','en'),(9,'apathetic','1','en'),(10,'artistic','1','en'),(11,'awake','1','en'),(12,'bitchy','1','en'),(13,'blah','1','en'),(14,'blank','1','en'),(15,'bored','1','en'),(16,'bouncy','1','en'),(17,'busy','1','en'),(18,'calm','1','en'),(19,'cheerful','1','en'),(20,'chipper','1','en'),(21,'cold','1','en'),(22,'complacent','1','en'),(23,'confused','1','en'),(24,'contemplative','1','en'),(25,'content','1','en'),(26,'cranky','1','en'),(27,'crappy','1','en'),(28,'crazy','1','en'),(29,'creative','1','en'),(30,'crushed','1','en'),(31,'curious','1','en'),(32,'cynical','1','en'),(33,'depressed','1','en'),(34,'determined','1','en'),(35,'devious','1','en'),(36,'dirty','1','en'),(37,'disappointed','1','en'),(38,'discontent','1','en'),(39,'distressed','1','en'),(40,'ditzy','1','en'),(41,'dorky','1','en'),(42,'drained','1','en'),(43,'drunk','1','en'),(44,'ecstatic','1','en'),(45,'embarrassed','1','en'),(46,'energetic','1','en'),(47,'enraged','1','en'),(48,'enthralled','1','en'),(49,'envious','1','en'),(50,'exanimate','1','en'),(51,'excited','1','en'),(52,'exhausted','1','en'),(53,'flirty','1','en'),(54,'frustrated','1','en'),(55,'full','1','en'),(56,'geeky','1','en'),(57,'giddy','1','en'),(58,'giggly','1','en'),(59,'gloomy','1','en'),(60,'good','1','en'),(61,'grateful','1','en'),(62,'groggy','1','en'),(63,'grumpy','1','en'),(64,'guilty','1','en'),(65,'happy','1','en'),(66,'high','1','en'),(67,'hopeful','1','en'),(68,'horny','1','en'),(69,'hot','1','en'),(70,'hungry','1','en'),(71,'hyper','1','en'),(72,'impressed','1','en'),(73,'indescribable','1','en'),(74,'indifferent','1','en'),(75,'infuriated','1','en'),(76,'intimidated','1','en'),(77,'irate','1','en'),(78,'irritated','1','en'),(79,'jealous','1','en'),(80,'jubilant','1','en'),(81,'lazy','1','en'),(82,'lethargic','1','en'),(83,'listless','1','en'),(84,'lonely','1','en'),(85,'loved','1','en'),(86,'melancholy','1','en'),(87,'mellow','1','en'),(88,'mischievous','1','en'),(89,'moody','1','en'),(90,'morose','1','en'),(91,'naughty','1','en'),(92,'nauseated','1','en'),(93,'nerdy','1','en'),(94,'nervous','1','en'),(95,'nostalgic','1','en'),(96,'numb','1','en'),(97,'okay','1','en'),(98,'optimistic','1','en'),(99,'peaceful','1','en'),(100,'pensive','1','en'),(101,'pessimistic','1','en'),(102,'pissed off','1','en'),(103,'pleased','1','en'),(104,'predatory','1','en'),(105,'productive','1','en'),(106,'quixotic','1','en'),(107,'recumbent','1','en'),(108,'refreshed','1','en'),(109,'rejected','1','en'),(110,'rejuvenated','1','en'),(111,'relaxed','1','en'),(112,'relieved','1','en'),(113,'restless','1','en'),(114,'rushed','1','en'),(115,'sad','1','en'),(116,'satisfied','1','en'),(117,'scared','1','en'),(118,'shocked','1','en'),(119,'sick','1','en'),(120,'silly','1','en'),(121,'sleepy','1','en'),(122,'sore','1','en'),(123,'stressed','1','en'),(124,'surprised','1','en'),(125,'sympathetic','1','en'),(126,'thankful','1','en'),(127,'thirsty','1','en'),(128,'thoughtful','1','en'),(129,'tired','1','en'),(130,'touched','1','en'),(131,'uncomfortable','1','en'),(132,'weird','1','en'),(133,'working','1','en'),(134,'worried','1','en'),(135,'Нет или другое','1','ru'),(136,'злое','1','ru'),(137,'раздражительное','1','ru'),(138,'скучающее','1','ru'),(139,'спокойное','1','ru'),(140,'радосное','1','ru'),(141,'щедрое','1','ru'),(142,'холодное','1','ru'),(143,'смущенное','1','ru'),(144,'сумасшедшее','1','ru'),(145,'пьяное','1','ru'),(146,'стыдливое','1','ru'),(147,'хорошее','1','ru'),(148,'благодарное','1','ru'),(149,'виноватое','1','ru'),(150,'счастливое','1','ru'),(151,'высокомерное','1','ru'),(152,'голодное','1','ru'),(153,'жалкое','1','ru'),(154,'одинокое','1','ru'),(155,'любящее','1','ru'),(156,'меланхолическое','1','ru'),(157,'ностальгичное','1','ru'),(158,'оптимистичное','1','ru'),(159,'умиротворенное','1','ru'),(160,'расслабленное','1','ru'),(161,'грусное','1','ru'),(162,'больное','1','ru'),(163,'глупое','1','ru'),(164,'сонное','1','ru'),(165,'уставшее','1','ru'),(166,'рабочее','1','ru'),(167,'обеспокоенное','1','ru'),(168,'Нема чи інше','1','uk'),(169,'зле','1','uk'),(170,'роздратоване','1','uk'),(171,'нудьгуюче','1','uk'),(172,'спокійне','1','uk'),(173,'радісне','1','uk'),(174,'щедре','1','uk'),(175,'холодне','1','uk'),(176,'збентежене','1','uk'),(177,'божевільне','1','uk'),(178,'п&#39янке','1','uk'),(179,'сором&#39язливе','1','uk'),(180,'добре','1','uk'),(181,'вдячне','1','uk'),(182,'винувате','1','uk'),(183,'щасливе','1','uk'),(184,'зарозуміле','1','uk'),(185,'голодне','1','uk'),(186,'жалюгідне','1','uk'),(187,'самотнье','1','uk'),(188,'любляче','1','uk'),(189,'меланхоличне','1','uk'),(190,'ностальгічний','1','uk'),(191,'оптимістичний','1','uk'),(192,'заспокоєне','1','uk'),(193,'розслабленне','1','uk'),(194,'зажурене','1','uk'),(195,'хворе','1','uk'),(196,'безглузде','1','uk'),(197,'сонне','1','uk'),(198,'втомлене','1','uk'),(199,'працююче','1','uk'),(200,'стурбоване','1','uk');
/*!40000 ALTER TABLE `y_moods` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

