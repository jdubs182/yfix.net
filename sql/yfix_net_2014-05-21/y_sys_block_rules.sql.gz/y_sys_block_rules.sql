
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `y_sys_block_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `y_sys_block_rules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `block_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rule_type` enum('DENY','ALLOW') NOT NULL DEFAULT 'DENY',
  `user_groups` varchar(255) NOT NULL DEFAULT '',
  `methods` text NOT NULL,
  `themes` text NOT NULL,
  `locales` text NOT NULL,
  `others` text NOT NULL,
  `active` enum('1','0') NOT NULL DEFAULT '1',
  `order` int(10) unsigned NOT NULL DEFAULT '0',
  `site_ids` varchar(1000) NOT NULL,
  `server_ids` varchar(1000) NOT NULL,
  `server_roles` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `y_sys_block_rules` WRITE;
/*!40000 ALTER TABLE `y_sys_block_rules` DISABLE KEYS */;
INSERT INTO `y_sys_block_rules` VALUES (1,1,'ALLOW','','','','','','1',1,'','',''),(2,4,'ALLOW','1','','','','','1',1,'','',''),(3,2,'ALLOW','','','','','','1',0,'','',''),(4,3,'ALLOW','','blog.show_posts,blog.show_single_post,gallery.show_gallery,gallery.show_medium_size,gallery.view_folder,user_profile.show','','','','1',1,'','',''),(5,3,'DENY','','blog.show,blog.show_all_blogs,blog.add_post,blog.edit_post,gallery.show,gallery.add_photo,gallery.edit_photo','','','','1',2,'','',''),(6,6,'ALLOW',',4,','','','','','1',4,'','',''),(7,7,'ALLOW','','','','','','1',0,'','',''),(8,8,'ALLOW','','','','','','1',0,'','',''),(9,9,'ALLOW','','','','','','1',0,'','',''),(10,10,'ALLOW','','','','','','1',0,'','',''),(13,4,'ALLOW',',2,',',admin_account,\nadmin_home,\nadmin_wall,\nmanage_shop.filter_save,\nmanage_shop.orders,\nmanage_shop.orders_manage,\nmanage_shop.product_activate,\nmanage_shop.product_add,\nmanage_shop.product_delete,\nmanage_shop.product_edit,\nmanage_shop.product_image_delete,\nmanage_shop.product_image_search,\nmanage_shop.product_image_upload,\nmanage_shop.products,\nmanage_shop.show_orders,\nmanage_shop.view_order,\nshop_supplier_panel,','','','','1',2,'','',''),(14,12,'ALLOW','','','','','','1',0,'','',''),(15,13,'ALLOW','','','','','','1',0,'','',''),(16,14,'ALLOW','','','','','','1',0,'','',''),(18,6,'ALLOW',',2,','','','','','1',3,'','',''),(19,15,'ALLOW','','','','','','1',0,'','',''),(23,20,'ALLOW','','','','','','1',0,'','',''),(24,16,'ALLOW','','','','','','1',0,'','',''),(25,21,'ALLOW','','','','','','1',0,'','',''),(27,6,'ALLOW',',1,','','','','','1',0,'','',''),(28,4,'ALLOW',',4,','admin_account,\nadmin_home,\nadmin_wall,\nmanage_shop.filter_save,\nmanage_shop.orders,\nmanage_shop.orders_manage,\nmanage_shop.product_edit,\nmanage_shop.product_add,\nmanage_shop.products,\nmanage_shop.send_sms,\nmanage_shop.show_orders,\nmanage_shop.view_order,\npaywill,','','','','1',5,'','',''),(34,4,'ALLOW',',3,','admin_account,\nadmin_home,\nadmin_wall,\nmanage_shop.attribute_activate,\nmanage_shop.attribute_add,\nmanage_shop.attribute_delete,\nmanage_shop.attribute_edit,\nmanage_shop.attributes,\nmanage_shop.filter_save,\nmanage_shop.product_activate,\nmanage_shop.product_add,\nmanage_shop.product_clone,\nmanage_shop.product_delete,\nmanage_shop.product_edit,\nmanage_shop.product_image_search,\nmanage_shop.product_image_upload,\nmanage_shop.product_image_delete,\nmanage_shop.products,\nmanage_shop.set_main_image,\n','','','','1',3,'','',''),(35,6,'ALLOW',',3,','','','','','1',3,'','',''),(36,22,'ALLOW','','','','','','1',0,'','','');
/*!40000 ALTER TABLE `y_sys_block_rules` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

