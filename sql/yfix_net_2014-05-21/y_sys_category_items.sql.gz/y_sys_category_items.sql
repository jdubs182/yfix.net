
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `y_sys_category_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `y_sys_category_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cat_id` int(10) unsigned NOT NULL,
  `parent_id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `desc` text NOT NULL,
  `meta_keywords` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `meta_desc` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(255) NOT NULL,
  `type_id` int(10) unsigned NOT NULL,
  `order` int(10) unsigned NOT NULL,
  `active` enum('1','0') NOT NULL,
  `restricted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `user_groups` varchar(255) NOT NULL,
  `other_info` text NOT NULL,
  `icon` varchar(255) NOT NULL,
  `image` enum('1','0') NOT NULL DEFAULT '0',
  `featured` tinyint(3) unsigned NOT NULL,
  `hide` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `filter` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `origin_url` varchar(255) NOT NULL,
  `force_wo_image` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=246 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `y_sys_category_items` WRITE;
/*!40000 ALTER TABLE `y_sys_category_items` DISABLE KEYS */;
INSERT INTO `y_sys_category_items` VALUES (1,2,0,'None','','','','',0,1,'1',0,'','','','0',0,0,0,'',0),(2,2,0,'Art and Photography','','','','',0,2,'1',0,'','','','0',0,0,0,'',0),(3,2,0,'Automotive','','','','',0,3,'1',0,'','','','0',0,0,0,'',0),(4,2,0,'Blogging','','','','',0,4,'1',0,'','','','0',0,0,0,'',0),(5,2,0,'Dreams and the Supernatural','','','','',0,5,'1',0,'','','','0',0,0,0,'',0),(6,2,0,'Fashion, Style, Shopping','','','','',0,6,'1',0,'','','','0',0,0,0,'',0),(7,2,0,'Food and Restaurants','','','','',0,7,'1',0,'','','','0',0,0,0,'',0),(8,2,0,'Friends','','','','',0,8,'1',0,'','','','0',0,0,0,'',0),(9,2,0,'Games','','','','',0,9,'1',0,'','','','0',0,0,0,'',0),(10,2,0,'Goals, Plans, Hopes','','','','',0,10,'1',0,'','','','0',0,0,0,'',0),(11,2,0,'Jobs, Work, Careers','','','','',0,11,'1',0,'','','','0',0,0,0,'',0),(12,2,0,'Life','','','','',0,12,'1',0,'','','','0',0,0,0,'',0),(13,2,0,'Movies, TV, Celebrities','','','','',0,13,'1',0,'','','','0',0,0,0,'',0),(14,2,0,'Music','','','','',0,14,'1',0,'','','','0',0,0,0,'',0),(16,2,0,'News and Politics','','','','',0,16,'1',0,'','','','0',0,0,0,'',0),(17,2,0,'Parties and Nightlife','','','','',0,17,'1',0,'','','','0',0,0,0,'',0),(18,2,0,'Pets and Animals','','','','',0,18,'1',0,'','','','0',0,0,0,'',0),(19,2,0,'Podcast','','','','',0,19,'1',0,'','','','0',0,0,0,'',0),(20,2,0,'Quiz/Survey','','','','',0,20,'1',0,'','','','0',0,0,0,'',0),(21,2,0,'Religion and Philosophy','','','','',0,21,'1',0,'','','','0',0,0,0,'',0),(22,2,0,'Romance and Relationships','','','','',0,22,'1',0,'','','','0',0,0,0,'',0),(23,2,0,'School, College, Greek','','','','',0,23,'1',0,'','','','0',0,0,0,'',0),(24,2,0,'Sports','','','','',0,24,'1',0,'','','','0',0,0,0,'',0),(25,2,0,'Travel and Places','','','','',0,25,'1',0,'','','','0',0,0,0,'',0),(26,2,0,'Web, HTML, Tech','','','','',0,26,'1',0,'','','','0',0,0,0,'',0),(27,2,0,'Writing and Poetry','','','','',0,27,'1',0,'','','','0',0,0,0,'',0),(28,1,0,'None','','','','testing',0,1,'1',0,'','','','0',0,0,0,'',0),(29,1,0,'Art and Photography','','','','',0,2,'1',0,'','','','0',0,0,0,'',0),(30,1,38,'Automotive','','','','automotive',0,3,'1',0,'','','','0',0,0,0,'',0),(31,1,0,'Blogging','','','','',0,4,'1',0,'','','','0',0,0,0,'',0),(32,1,0,'Dreams and the Supernatural','','','','',0,5,'1',0,'','','','0',0,0,0,'',0),(33,1,0,'Fashion, Style, Shopping','','','','',0,6,'1',0,'','','','0',0,0,0,'',0),(34,1,0,'Food and Restaurants','','','','',0,7,'1',0,'','','','0',0,0,0,'',0),(35,1,39,'Friends','','','','friends',0,8,'1',0,'','','','0',0,0,0,'',0),(36,1,0,'Games','','','','',0,9,'1',0,'','','','0',0,0,0,'',0),(37,1,0,'Goals, Plans, Hopes','','','','',0,10,'1',0,'','','','0',0,0,0,'',0),(38,1,0,'Jobs, Work, Careers','','','','',0,11,'1',0,'','','','0',0,0,0,'',0),(39,1,30,'Life','','','','life',0,12,'1',0,'','','','0',0,0,0,'',0),(40,1,39,'Movies, TV, Celebrities','','','','movies_tv_celebrities',0,13,'1',0,'','','','0',0,0,0,'',0),(41,1,39,'Music','','','','music',0,14,'1',0,'','','','0',0,0,0,'',0),(43,1,0,'News and Politics','','','','',0,16,'1',0,'','','','0',0,0,0,'',0),(44,1,0,'Parties and Nightlife','','','','',0,17,'1',0,'','','','0',0,0,0,'',0),(45,1,0,'Pets and Animals','','','','',0,18,'1',0,'','','','0',0,0,0,'',0),(46,1,0,'Podcast','','','','',0,19,'1',0,'','','','0',0,0,0,'',0),(47,1,0,'Quiz/Survey','','','','',0,20,'1',0,'','','','0',0,0,0,'',0),(48,1,0,'Religion and Philosophy','','','','',0,21,'1',0,'','','','0',0,0,0,'',0),(49,1,0,'Romance and Relationships','','','','',0,22,'1',0,'','','','0',0,0,0,'',0),(50,1,0,'School, College, Greek','','','','',0,23,'1',0,'','','','0',0,0,0,'',0),(51,1,39,'Sports','','','','sports',0,24,'1',0,'','','','0',0,0,0,'',0),(52,1,0,'Travel and Places','','','','',0,25,'1',0,'','','','0',0,0,0,'',0),(53,1,0,'Web, HTML, Tech','','','','',0,26,'1',0,'','','','0',0,0,0,'',0),(54,1,0,'Writing and Poetry','','','','',0,27,'1',0,'','','','0',0,0,0,'',0),(55,3,0,'Technical Issues','Technical Issues','','','',0,1,'1',0,'','','','0',0,0,0,'',0),(56,3,0,'Copyright Infringement','Copyright Infringement','','','',0,2,'1',0,'','','','0',0,0,0,'',0),(57,3,0,'False Info','False Info','','','',0,3,'1',0,'','','','0',0,0,0,'',0),(58,3,0,'Registration','Registration','','','',0,4,'1',0,'','','','0',0,0,0,'',0),(59,3,0,'Error Report','Error Report','','','',0,5,'1',0,'','','','0',0,0,0,'',0),(60,3,0,'Proposals','Proposals','','','',0,6,'1',0,'','','','0',0,0,0,'',0),(61,3,0,'Other','','','','',0,7,'1',0,'','','','0',0,0,0,'',0),(245,2,0,'Legal Issues','','','','legal_issues',0,7,'1',0,'','','','0',0,0,0,'',0);
/*!40000 ALTER TABLE `y_sys_category_items` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

