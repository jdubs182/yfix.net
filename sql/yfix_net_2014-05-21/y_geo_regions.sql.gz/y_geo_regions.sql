
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `y_geo_regions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `y_geo_regions` (
  `id` int(10) unsigned NOT NULL,
  `country` char(2) NOT NULL,
  `code` char(2) NOT NULL,
  `name` varchar(255) NOT NULL,
  `name_eng` varchar(255) NOT NULL,
  `capital_id` int(10) unsigned NOT NULL,
  `active` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `country` (`country`),
  KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `y_geo_regions` WRITE;
/*!40000 ALTER TABLE `y_geo_regions` DISABLE KEYS */;
INSERT INTO `y_geo_regions` VALUES (686966,'UA','27','Житомирская область','Zhytomyrs’ka Oblast’',686967,'1'),(687699,'UA','26','Запорожская область','Zaporiz’ka Oblast’',687700,'1'),(687869,'UA','25','Закарпатская область','Zakarpattia Oblast',690548,'1'),(689064,'UA','24','Волынская область','Volyns’ka Oblast’',702569,'1'),(689559,'UA','23','Винницкая область','Vinnyts’ka Oblast’',689558,'1'),(691649,'UA','22','Тернопольская область','Ternopil’s’ka Oblast’',691650,'1'),(692196,'UA','21','Сумская область','Sums’ka Oblast’',692194,'1'),(694422,'UA','20','Севастополь','Misto Sevastopol’',694423,'1'),(695592,'UA','19','Ровненская область','Rivnens’ka Oblast’',695594,'1'),(696634,'UA','18','Полтавская область','Poltavs’ka Oblast’',696643,'1'),(698738,'UA','17','Одесская область','Odes’ka Oblast’',698740,'1'),(700567,'UA','16','Николаевская область','Mykolayivs’ka Oblast’',700569,'1'),(702549,'UA','15','Львовская область','L’vivs’ka Oblast’',702550,'1'),(702657,'UA','14','Луганская область','Luhans’ka Oblast’',702658,'1'),(703446,'UA','13','Киевская область','Kyyivs’ka Oblast’',0,'1'),(703447,'UA','12','Киев','Misto Kyyiv',0,'1'),(703883,'UA','11','Автономная Республика Крым','Avtonomna Respublika Krym',693805,'1'),(705811,'UA','10','Кировоградская область','Kirovohrads’ka Oblast’',705812,'1'),(706370,'UA','09','Хмельницкая область','Khmel’nyts’ka Oblast’',706369,'1'),(706442,'UA','08','Херсонская область','Khersons’ka Oblast’',706448,'1'),(706482,'UA','07','Харьковская область','Kharkivs’ka Oblast’',706483,'1'),(707470,'UA','06','Ивано-Франковская область','Ivano-Frankivs’ka Oblast’',707471,'1'),(709716,'UA','05','Донецкая область','Donets’ka Oblast’',709717,'1'),(709929,'UA','04','Днепропетровская область','Dnipropetrovska Oblast\'',709930,'1'),(710720,'UA','03','Черновицкая область','Chernivets’ka Oblast’',710719,'1'),(710734,'UA','02','Черниговская область','Chernihivs’ka Oblast’',710735,'1'),(710802,'UA','01','Черкасская область','Cherkas’ka Oblast’',710791,'1');
/*!40000 ALTER TABLE `y_geo_regions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

