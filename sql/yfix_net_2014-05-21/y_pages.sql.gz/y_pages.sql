
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `y_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `y_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `locale` char(5) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `heading` varchar(255) NOT NULL DEFAULT '',
  `text` longtext NOT NULL,
  `meta_keywords` text NOT NULL,
  `meta_desc` text NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `content_type` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `active` enum('1','0') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `locale` (`locale`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `y_pages` WRITE;
/*!40000 ALTER TABLE `y_pages` DISABLE KEYS */;
INSERT INTO `y_pages` VALUES (1,'','docs_helpers','Helper Functions','','<p><span style=\"color: inherit; font-family: inherit; font-size: 24.5px; font-weight: bold; line-height: 42px;\">array_add</span><br></p><p>The&nbsp;<code>array_add</code>&nbsp;function adds a given key / value pair to the array if the given key doesn\'t already exist in the array.</p><pre><code>$array = array(\'foo\' =&gt; \'bar\');\r\n\r\n$array = array_add($array, \'key\', \'value\');</code></pre><h3>array_divide</h3><p>The&nbsp;<code>array_divide</code>&nbsp;function returns two arrays, one containing the keys, and the other containing the values of the original array.</p><pre><code>$array = array(\'foo\' =&gt; \'bar\');\r\n\r\nlist($keys, $values) = array_divide($array);</code></pre><h3>array_dot</h3><p>The&nbsp;<code>array_dot</code>&nbsp;function flattens a multi-dimensional array into a single level array that uses \"dot\" notation to indicate depth.</p><pre><code>$array = array(\'foo\' =&gt; array(\'bar\' =&gt; \'baz\'));\r\n\r\n$array = array_dot($array);\r\n\r\n// array(\'foo.bar\' =&gt; \'baz\');</code></pre><h3>array_except</h3><p>The&nbsp;<code>array_except</code>&nbsp;method removes the given key / value pairs from the array.</p><pre><code>$array = array_except($array, array(\'keys\', \'to\', \'remove\'));</code></pre><h3>array_fetch</h3><p>The&nbsp;<code>array_fetch</code>&nbsp;method returns a flattened array containing the selected nested element.</p><pre><code>$array = array(\r\n    array(\'developer\' =&gt; array(\'name\' =&gt; \'Taylor\')),\r\n    array(\'developer\' =&gt; array(\'name\' =&gt; \'Dayle\')),\r\n);\r\n\r\n$array = array_fetch($array, \'developer.name\');\r\n\r\n// array(\'Taylor\', \'Dayle\');</code></pre><h3>array_first</h3><p>The&nbsp;<code>array_first</code>&nbsp;method returns the first element of an array passing a given truth test.</p><pre><code>$array = array(100, 200, 300);\r\n\r\n$value = array_first($array, function($key, $value)\r\n{\r\n    return $value &gt;= 150;\r\n});</code></pre><p>A default value may also be passed as the third parameter:</p><pre><code>$value = array_first($array, $callback, $default);</code></pre><h3>array_last</h3><p>The&nbsp;<code>array_last</code>&nbsp;method returns the last element of an array passing a given truth test.</p><pre><code>$array = array(350, 400, 500, 300, 200, 100);\r\n\r\n$value = array_last($array, function($key, $value)\r\n{\r\n    return $value &gt; 350;\r\n});\r\n\r\n// 500</code></pre><p>A default value may also be passed as the third parameter:</p><pre><code>$value = array_last($array, $callback, $default);</code></pre><h3>array_flatten</h3><p>The&nbsp;<code>array_flatten</code>&nbsp;method will flatten a multi-dimensional array into a single level.</p><pre><code>$array = array(\'name\' =&gt; \'Joe\', \'languages\' =&gt; array(\'PHP\', \'Ruby\'));\r\n\r\n$array = array_flatten($array);\r\n\r\n// array(\'Joe\', \'PHP\', \'Ruby\');</code></pre><h3>array_forget</h3><p>The&nbsp;<code>array_forget</code>&nbsp;method will remove a given key / value pair from a deeply nested array using \"dot\" notation.</p><pre><code>$array = array(\'names\' =&gt; array(\'joe\' =&gt; array(\'programmer\')));\r\n\r\narray_forget($array, \'names.joe\');</code></pre><h3>array_get</h3><p>The&nbsp;<code>array_get</code>&nbsp;method will retrieve a given value from a deeply nested array using \"dot\" notation.</p><pre><code>$array = array(\'names\' =&gt; array(\'joe\' =&gt; array(\'programmer\')));\r\n\r\n$value = array_get($array, \'names.joe\');</code></pre><blockquote><p><strong>Note:</strong>&nbsp;Want something like&nbsp;<code>array_get</code>&nbsp;but for objects instead? Use&nbsp;<code>object_get</code>.</p></blockquote><h3>array_only</h3><p>The&nbsp;<code>array_only</code>&nbsp;method will return only the specified key / value pairs from the array.</p><pre><code>$array = array(\'name\' =&gt; \'Joe\', \'age\' =&gt; 27, \'votes\' =&gt; 1);\r\n\r\n$array = array_only($array, array(\'name\', \'votes\'));</code></pre><h3>array_pluck</h3><p>The&nbsp;<code>array_pluck</code>&nbsp;method will pluck a list of the given key / value pairs from the array.</p><pre><code>$array = array(array(\'name\' =&gt; \'Taylor\'), array(\'name\' =&gt; \'Dayle\'));\r\n\r\n$array = array_pluck($array, \'name\');\r\n\r\n// array(\'Taylor\', \'Dayle\');</code></pre><h3>array_pull</h3><p>The&nbsp;<code>array_pull</code>&nbsp;method will return a given key / value pair from the array, as well as remove it.</p><pre><code>$array = array(\'name\' =&gt; \'Taylor\', \'age\' =&gt; 27);\r\n\r\n$name = array_pull($array, \'name\');</code></pre><h3>array_set</h3><p>The&nbsp;<code>array_set</code>&nbsp;method will set a value within a deeply nested array using \"dot\" notation.</p><pre><code>$array = array(\'names\' =&gt; array(\'programmer\' =&gt; \'Joe\'));\r\n\r\narray_set($array, \'names.editor\', \'Taylor\');</code></pre><h3>array_sort</h3><p>The&nbsp;<code>array_sort</code>&nbsp;method sorts the array by the results of the given Closure.</p><pre><code>$array = array(\r\n    array(\'name\' =&gt; \'Jill\'),\r\n    array(\'name\' =&gt; \'Barry\'),\r\n);\r\n\r\n$array = array_values(array_sort($array, function($value)\r\n{\r\n    return $value[\'name\'];\r\n}));</code></pre><h3>array_where</h3><p>Filter the array using the given Closure.</p><pre><code>$array = array(100, \'200\', 300, \'400\', 500);\r\n\r\n$array = array_where($array, function($key, $value)\r\n{\r\n    return is_string($value);\r\n});\r\n\r\n// Array ( [1] =&gt; 200 [3] =&gt; 400 )</code></pre><h3>head</h3><p>Return the first element in the array. Useful for method chaining in PHP 5.3.x.</p><pre><code>$first = head($this-&gt;returnsArray(\'foo\'));</code></pre><h3>last</h3><p>Return the last element in the array. Useful for method chaining.</p><pre><code>$last = last($this-&gt;returnsArray(\'foo\'));</code></pre><p><strong>value</strong></p><p>If the given value is a&nbsp;<code>Closure</code>, return the value returned by the&nbsp;<code>Closure</code>. Otherwise, return the value.</p><pre><code>$value = value(function() { return \'bar\'; });</code></pre><h3>with</h3><p>Return the given object. Useful for method chaining constructors in PHP 5.3.x.</p><pre><code>$value = with(new Foo)-&gt;doWork();</code></pre>','','','2014-05-16 13:15:50','2014-05-16 14:24:30',1,'1');
/*!40000 ALTER TABLE `y_pages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

