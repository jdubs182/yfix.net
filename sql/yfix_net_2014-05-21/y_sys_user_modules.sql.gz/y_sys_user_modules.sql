
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `y_sys_user_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `y_sys_user_modules` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `version` varchar(16) NOT NULL DEFAULT '',
  `author` varchar(255) NOT NULL DEFAULT '',
  `active` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `y_sys_user_modules` WRITE;
/*!40000 ALTER TABLE `y_sys_user_modules` DISABLE KEYS */;
INSERT INTO `y_sys_user_modules` VALUES (1,'home_page','','','','1'),(2,'login_form','','','','1'),(3,'static_pages','','','','1'),(7,'account','','','','1'),(8,'activity','','','','1'),(9,'articles','','','','1'),(10,'blog','','','','1'),(11,'chat','','','','1'),(12,'comments','','','','1'),(13,'dynamic','','','','1'),(14,'faq','','','','1'),(15,'forum','','','','1'),(16,'friends','','','','1'),(17,'gallery','','','','1'),(18,'geo_content','','','','1'),(19,'get_pswd','','','','1'),(20,'help','','','','1'),(21,'interests','','','','1'),(22,'language','','','','1'),(23,'mail','','','','1'),(24,'photo_rating','','','','1'),(25,'poll','','','','1'),(26,'rate','','','','1'),(27,'register','','','','1'),(28,'reputation','','','','1'),(29,'site_map','','','','1'),(30,'site_nav_bar','','','','1'),(31,'stats','','','','1'),(32,'task_loader','','','','1'),(33,'test','','','','1'),(34,'user_info','','','','1'),(35,'user_profile','','','','1'),(39,'banner_rotator','','','','1'),(40,'calendar','','','','1'),(41,'community','','','','1'),(42,'email','','','','1'),(43,'layout_settings','','','','1'),(44,'news','','','','1'),(45,'openid','','','','1'),(46,'right_block','','','','1'),(47,'search','','','','1'),(48,'tags','','','','1'),(49,'users','','','','1'),(50,'users_search','','','','1'),(52,'widgets','','','','1'),(53,'rss','','','','1'),(54,'shop','','','','1');
/*!40000 ALTER TABLE `y_sys_user_modules` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

