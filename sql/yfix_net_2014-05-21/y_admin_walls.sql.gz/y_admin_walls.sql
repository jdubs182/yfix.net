
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `y_admin_walls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `y_admin_walls` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL DEFAULT '0',
  `message` text NOT NULL,
  `object` varchar(255) NOT NULL DEFAULT '',
  `action` varchar(255) NOT NULL DEFAULT '',
  `object_id` int(11) unsigned NOT NULL DEFAULT '0',
  `server_id` int(11) unsigned NOT NULL DEFAULT '0',
  `site_id` int(11) unsigned NOT NULL DEFAULT '0',
  `important` int(11) unsigned NOT NULL DEFAULT '0',
  `old_data` text NOT NULL,
  `new_data` text NOT NULL,
  `add_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `y_admin_walls` WRITE;
/*!40000 ALTER TABLE `y_admin_walls` DISABLE KEYS */;
INSERT INTO `y_admin_walls` VALUES (1,1,'menu: user_main_menu inactivated','menus_editor','active',2,0,1,0,'\"\"','\"\"','2014-04-02 12:36:51'),(2,1,'menu: user_side_menu inactivated','menus_editor','active',4,0,1,0,'\"\"','\"\"','2014-04-02 12:36:54'),(3,1,'menu: admin_top_menu inactivated','menus_editor','active',3,0,1,0,'\"\"','\"\"','2014-04-02 12:37:00'),(4,1,'menu: admin_left_menu inactivated','menus_editor','active',1,0,1,0,'\"\"','\"\"','2014-04-02 12:37:04'),(5,1,'menu item deleted: Upload images','menus_editor','delete_item',1437,0,1,0,'\"\"','\"\"','2014-04-02 12:37:18'),(6,1,'menu item deleted: Products','menus_editor','delete_item',1440,0,1,0,'\"\"','\"\"','2014-04-02 12:37:20'),(7,1,'menu item deleted: Content-manager','menus_editor','delete_item',1438,0,1,0,'\"\"','\"\"','2014-04-02 12:37:21'),(8,1,'menu item deleted: Import products','menus_editor','delete_item',1434,0,1,0,'\"\"','\"\"','2014-04-02 12:37:23'),(9,1,'menu item deleted: Upload images','menus_editor','delete_item',1428,0,1,0,'\"\"','\"\"','2014-04-02 12:37:24'),(10,1,'menu item deleted: Category mapping','menus_editor','delete_item',1429,0,1,0,'\"\"','\"\"','2014-04-02 12:37:26'),(11,1,'menu item deleted: Orders','menus_editor','delete_item',1430,0,1,0,'\"\"','\"\"','2014-04-02 12:37:27'),(12,1,'menu item deleted: Products','menus_editor','delete_item',1427,0,1,0,'\"\"','\"\"','2014-04-02 12:37:28'),(13,1,'menu item deleted: Supplier Shop','menus_editor','delete_item',1436,0,1,0,'\"\"','\"\"','2014-04-02 12:37:29'),(14,1,'menu item deleted: Logs','menus_editor','delete_item',1443,0,1,0,'\"\"','\"\"','2014-04-02 12:37:30'),(15,1,'menu item deleted: Feedback','menus_editor','delete_item',1441,0,1,0,'\"\"','\"\"','2014-04-02 12:37:31'),(16,1,'menu item deleted: Express','menus_editor','delete_item',1442,0,1,0,'\"\"','\"\"','2014-04-02 12:37:31'),(17,1,'menu item deleted: Promotions','menus_editor','delete_item',1435,0,1,0,'\"\"','\"\"','2014-04-02 12:37:32'),(18,1,'menu item deleted: Upload images','menus_editor','delete_item',1433,0,1,0,'\"\"','\"\"','2014-04-02 12:37:33'),(19,1,'menu item deleted: Customers','menus_editor','delete_item',1417,0,1,0,'\"\"','\"\"','2014-04-02 12:37:33'),(20,1,'menu item deleted: Configuration','menus_editor','delete_item',1418,0,1,0,'\"\"','\"\"','2014-04-02 12:37:34'),(21,1,'menu item deleted: Categories','menus_editor','delete_item',1416,0,1,0,'\"\"','\"\"','2014-04-02 12:37:34'),(22,1,'menu item deleted: Orders','menus_editor','delete_item',1415,0,1,0,'\"\"','\"\"','2014-04-02 12:37:35'),(23,1,'menu item deleted: Attributes','menus_editor','delete_item',1412,0,1,0,'\"\"','\"\"','2014-04-02 12:37:36'),(24,1,'menu item deleted: Product Sets','menus_editor','delete_item',1422,0,1,0,'\"\"','\"\"','2014-04-02 12:37:37'),(25,1,'menu item deleted: Suppliers','menus_editor','delete_item',1410,0,1,0,'\"\"','\"\"','2014-04-02 12:37:38'),(26,1,'menu item deleted: Manufacturers','menus_editor','delete_item',1411,0,1,0,'\"\"','\"\"','2014-04-02 12:37:39'),(27,1,'menu item deleted: Products','menus_editor','delete_item',1413,0,1,0,'\"\"','\"\"','2014-04-02 12:37:40'),(28,1,'menu item deleted: Dashboard','menus_editor','delete_item',1414,0,1,0,'\"\"','\"\"','2014-04-02 12:37:40'),(29,1,'menu item deleted: Shop','menus_editor','delete_item',1431,0,1,0,'\"\"','\"\"','2014-04-02 12:37:42'),(30,1,'menu item deleted: Search Engine Keywords','menus_editor','delete_item',1373,0,1,0,'\"\"','\"\"','2014-04-02 12:37:47'),(31,1,'menu item deleted: Image Resize','menus_editor','delete_item',1372,0,1,0,'\"\"','\"\"','2014-04-02 12:37:54'),(32,1,'menu item deleted: User dynamic info','menus_editor','delete_item',1354,0,1,0,'\"\"','\"\"','2014-04-02 12:37:59'),(33,1,'menu items updated: admin_home_menu','menus_editor','show_items',5,0,1,0,'\"\"','\"\"','2014-04-02 12:38:10'),(34,1,'page added: docs_helpers','manage_pages','add',1,0,1,0,'\"\"','\"\"','2014-05-16 13:15:50'),(35,1,'page updated: docs_helpers','manage_pages','edit',1,0,1,0,'\"\"','\"\"','2014-05-16 13:16:37'),(36,1,'page updated: docs_helpers','manage_pages','edit',1,0,1,0,'\"\"','\"\"','2014-05-16 13:17:45'),(37,1,'page updated: docs_helpers','manage_pages','edit',1,0,1,0,'\"\"','\"\"','2014-05-16 14:23:35'),(38,1,'page updated: docs_helpers','manage_pages','edit',1,0,1,0,'\"\"','\"\"','2014-05-16 14:24:30');
/*!40000 ALTER TABLE `y_admin_walls` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

