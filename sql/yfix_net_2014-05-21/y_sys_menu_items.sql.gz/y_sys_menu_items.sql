
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `y_sys_menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `y_sys_menu_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` int(10) unsigned NOT NULL,
  `parent_id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `type_id` int(10) unsigned NOT NULL,
  `order` int(10) unsigned NOT NULL,
  `active` enum('1','0') NOT NULL,
  `user_groups` varchar(255) NOT NULL,
  `site_ids` varchar(255) NOT NULL,
  `server_ids` varchar(255) NOT NULL,
  `cond_code` varchar(255) NOT NULL DEFAULT '',
  `icon` varchar(255) NOT NULL,
  `other_info` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1422 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `y_sys_menu_items` WRITE;
/*!40000 ALTER TABLE `y_sys_menu_items` DISABLE KEYS */;
INSERT INTO `y_sys_menu_items` VALUES (1,4,0,'Account','object=account',1,1,'1','','','','','',''),(2,4,0,'Edit profile','object=user_info',1,2,'1','','','','','',''),(3,4,0,'View profile','object=user_profile',1,3,'1','','','','','',''),(4,4,0,'Email','object=email&action=inbox',1,4,'1','','','','','',''),(5,4,0,'My blog','object=blog&action=show_posts',1,6,'1','','','','','',''),(6,4,0,'My gallery','object=gallery&action=show_gallery',1,7,'1','','','','','',''),(7,4,0,'My interests','object=interests&action=manage',1,8,'1','','','','','',''),(8,4,0,'Favorite Users','object=account&action=edit_favorites',1,9,'1','','','','','',''),(9,4,0,'Ignored Users','object=account&action=edit_ignored',1,10,'1','','','','','',''),(10,4,0,'Friends','object=friends&action=view_all_friends',1,11,'1','','','','','',''),(11,4,0,'Friend Of','object=friends&action=view_all_friend_of',1,12,'1','','','','','',''),(12,4,0,'Logout','task=logout',1,14,'1','','','','','',''),(13,4,0,'My articles','object=articles&action=manage',1,5,'1','','','','','',''),(14,4,0,'Tags','object=tags',1,13,'1','','','','','',''),(20,2,0,'Forum','object=forum',1,2,'1','','','','','',''),(21,2,0,'Home','object=home_page',1,0,'1','','','','','',''),(22,2,0,'FAQ','object=static_pages&action=show&id=faq',1,8,'1','','','','','',''),(23,2,0,'About','object=static_pages&action=show&id=about',1,9,'1','','','','','',''),(24,2,0,'Terms','object=static_pages&action=show&id=terms',1,6,'1','','','','','',''),(25,2,0,'Privacy','object=static_pages&action=show&id=privacy',1,7,'1','','','','','',''),(28,2,0,'Interests','object=interests',1,5,'1','','','','','',''),(29,2,0,'Blog','object=blog',1,3,'1','','','','','',''),(31,2,0,'Gallery','object=gallery',1,4,'1','','','','','',''),(32,2,0,'Contact Us','object=help&action=email_form',1,10,'1','','','','','',''),(34,2,0,'News','object=news',1,1,'1','','','','','',''),(35,2,0,'Articles','object=articles',1,2,'1','','','','','',''),(37,2,0,'Shop','object=shop',1,1,'1','','','','','',''),(1274,5,0,'Tools','',3,1,'1','','','','','',''),(1290,5,0,'Administration','',3,11,'1','','','','','',''),(1296,5,1290,'Logs','',3,22,'1','','','','','',''),(1306,5,1290,'Users','',3,15,'1','','','','','',''),(1312,5,0,'Content','',3,28,'1','','','','','',''),(1353,5,1274,'File manager','object=file_manager',1,3,'1','','','','','',''),(1355,5,1274,'Database manager','object=db_manager',1,7,'1','','','','','',''),(1357,5,1274,'Menus manager','object=menus_editor',1,5,'1','','','','','',''),(1358,5,1274,'Categories editor','object=category_editor',1,4,'1','','','','','',''),(1359,5,1274,'Blocks editor','object=blocks',1,2,'1','','','','','',''),(1361,5,1274,'Locale Editor','object=locale_editor',1,8,'1','','','','','',''),(1362,5,1274,'Tips Editor','object=manage_tips',1,10,'1','','','','','',''),(1364,5,1290,'Admin Groups','object=admin_groups',1,12,'1','','','','','',''),(1365,5,1290,'Admin Management','object=admin',1,13,'1','','','','','',''),(1366,5,1306,'User Modules Manager','object=user_modules',1,18,'1','','','','','',''),(1367,5,1290,'Admin Modules Manager','object=admin_modules',1,14,'1','','','','','',''),(1368,5,1296,'Execution Log Analyzer','object=log_exec_analyser',1,27,'0','','','','','',''),(1369,5,1296,'Core Errors','object=log_core_errors_viewer',1,23,'1','','','','','',''),(1370,5,1296,'User Errors','object=log_user_errors_viewer',1,24,'1','','','','','',''),(1371,5,1296,'Emails','object=log_emails_viewer',1,26,'1','','','','','',''),(1374,5,1296,'Authentification fails','object=log_auth_fails_viewer',1,25,'1','','','','','',''),(1377,5,1306,'User Groups','object=user_groups',1,16,'1','','','','','',''),(1378,5,1306,'User Management','object=members',1,17,'1','','','','','',''),(1379,5,1306,'Online Users','object=online_users_manager',1,20,'0','','','','','',''),(1380,5,1306,'Registration Confirmation','object=confirm_reg',1,19,'1','','','','','',''),(1381,5,1312,'Static Pages','object=static_pages',1,29,'1','','','','','',''),(1382,5,1312,'Forum','object=forum',1,32,'0','','','','','',''),(1383,5,1312,'Gallery','object=gallery',1,33,'0','','','','','',''),(1384,5,1312,'Blog','object=manage_blogs',1,34,'0','','','','','',''),(1385,5,1312,'Articles','object=manage_articles',1,35,'0','','','','','',''),(1386,5,1312,'News','object=manage_news',1,30,'1','','','','','',''),(1387,5,1312,'Comments','object=manage_comments',1,31,'1','','','','','',''),(1388,5,1230,'Alerts','object=account&action=manage_alerts',1,0,'1','','','','','',''),(1389,5,1346,'Email alerts logs','object=log_alert_emails',1,0,'1','','','','','',''),(1397,5,1324,'Edit Account Info','object=admin_home&action=edit_account',1,0,'1','','','','','',''),(1398,5,1398,'Logout','task=logout',1,0,'1','','','','','',''),(1408,5,1306,'Help Tickets','object=help_tickets',1,21,'0','','','','','',''),(1420,5,1274,'Settings','object=settings',1,9,'1','','','','','',''),(1421,5,1274,'Dashboards','object=manage_dashboards',1,6,'1','','','','','','');
/*!40000 ALTER TABLE `y_sys_menu_items` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

