
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `y_sys_admin_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `y_sys_admin_modules` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `version` varchar(16) NOT NULL,
  `author` varchar(255) NOT NULL,
  `active` enum('0','1') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `y_sys_admin_modules` WRITE;
/*!40000 ALTER TABLE `y_sys_admin_modules` DISABLE KEYS */;
INSERT INTO `y_sys_admin_modules` VALUES (2,'admin','','','','1'),(3,'admin_groups','','','','1'),(4,'admin_home','','','','1'),(5,'admin_messages','','','','1'),(6,'admin_modules','','','','1'),(7,'backup_manager','','','','1'),(8,'blocks','','','','1'),(9,'category_editor','','','','1'),(10,'check_multi_accounts','','','','1'),(11,'conf_editor','','','','1'),(13,'custom_bbcode_editor','','','','1'),(14,'custom_replace','','','','1'),(15,'db_manager','','','','1'),(19,'file_manager','','','','1'),(23,'locale_editor','','','','1'),(26,'log_core_errors_viewer','','','','0'),(28,'log_exec_analyser','','','','0'),(30,'log_user_errors_viewer','','','','0'),(38,'members','','','','1'),(39,'menus_editor','','','','1'),(40,'online_users_manager','','','','1'),(44,'revisions_manager','','','','1'),(46,'settings','','','','1'),(48,'site_nav_bar','','','','1'),(49,'static_pages','','','','1'),(51,'template_editor','','','','1'),(52,'user_dynamic_info','','','','1'),(53,'user_groups','','','','1'),(55,'user_modules','','','','1'),(58,'analyze_admin_exec_log','','','','0'),(59,'analyze_engine_log','','','','0'),(60,'analyze_error_log','','','','0'),(61,'ban_editor','','','','0'),(65,'log_admin_exec','','','','0'),(67,'log_ssh_viewer','','','','0'),(68,'log_webshell_actions_viewer','','','','0'),(69,'manage_auto_ban','','','','0'),(70,'manage_dynamic_attributes','','','','0'),(72,'manage_shop','','','','1'),(73,'manage_sphinx','','','','0'),(76,'manage_conf','','','','1'),(77,'manage_servers','','','','0'),(78,'manage_sites','','','','0'),(79,'manage_advertising','','','','0'),(80,'manage_dashboards','','','','1'),(81,'manage_tips','','','','1'),(82,'admin_wall','','','','1'),(83,'manage_widgets','','','','0'),(84,'shop_supplier_panel','','','','1'),(85,'admin_account','','','','1'),(86,'manage_users','','','','0'),(87,'manage_countries','','','','0'),(88,'manage_currencies','','','','0'),(89,'manage_icons','','','','0'),(90,'manage_languages','','','','0'),(91,'manage_regions','','','','0'),(92,'manage_timezones','','','','0'),(93,'shop_contentm_panel','','','','1'),(94,'manage_cities','','','','0'),(95,'activity_viewer','','','','0'),(96,'dev','','','','0'),(97,'help_tickets','','','','0'),(98,'manage_articles','','','','0'),(99,'manage_blogs','','','','0'),(100,'manage_comments','','','','1'),(101,'manage_faq','','','','0'),(102,'manage_forum','','','','0'),(103,'manage_news','','','','1'),(104,'manage_reput','','','','0'),(105,'polls_manager','','','','0'),(106,'se_keywords_manager','','','','0'),(107,'merge_products','','','','1'),(108,'parse_ambar_site','','','','1'),(109,'parse_eda_lg_site','','','','1'),(110,'parse_vseprodam_site','','','','1'),(111,'parse_zakaz_site','','','','1'),(112,'paywill','','','','1'),(113,'log_admin_auth','','','','0'),(114,'log_admin_auth_fails','','','','0'),(115,'log_user_auth','','','','0'),(116,'log_user_auth_fails','','','','0'),(117,'manage_shop_promo','','','','1');
/*!40000 ALTER TABLE `y_sys_admin_modules` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

