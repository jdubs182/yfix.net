
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `y_sys_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `y_sys_blocks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '',
  `desc` varchar(255) NOT NULL DEFAULT '',
  `stpl_name` varchar(255) NOT NULL,
  `method_name` varchar(255) NOT NULL,
  `type` enum('user','admin') NOT NULL,
  `active` enum('1','0') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `y_sys_blocks` WRITE;
/*!40000 ALTER TABLE `y_sys_blocks` DISABLE KEYS */;
INSERT INTO `y_sys_blocks` VALUES (1,'center_area','','','main.tasks','user','1'),(2,'left_area','','','','user','1'),(3,'right_area','','','','user','1'),(4,'center_area','','','main.tasks','admin','1'),(6,'left_area','','','','admin','1'),(7,'basket_micro','','','shop._basket_micro','user','1'),(8,'head_nav','','','shop._block_nav_head','user','1'),(9,'products_latest','','','shop._block_products_latest','user','1'),(10,'products_latest_sold','','','shop._block_products_latest_sold','user','1'),(12,'products_popular','','','shop._block_products_popular','user','1'),(13,'products_closeout','','','shop._block_products_closeout','user','1'),(14,'products_also_purchased','','','shop._block_products_also_purchased','user','1'),(15,'product_sets_top','','','shop._block_product_sets_top','user','1'),(16,'product_sets_left','','','shop._block_product_sets_left','user','1'),(20,'product_sets_center','','','shop._block_product_sets_center','user','1'),(21,'product_sets_top_clone','','','shop._block_product_sets_top','user','0'),(22,'products_viewed','','','shop._block_products_viewed','user','1');
/*!40000 ALTER TABLE `y_sys_blocks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

