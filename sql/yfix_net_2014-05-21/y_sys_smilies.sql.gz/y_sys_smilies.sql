
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `y_sys_smilies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `y_sys_smilies` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL,
  `emoticon` varchar(75) DEFAULT NULL,
  `emo_set` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `y_sys_smilies` WRITE;
/*!40000 ALTER TABLE `y_sys_smilies` DISABLE KEYS */;
INSERT INTO `y_sys_smilies` VALUES (1,':mellow:','mellow.gif','mellow',2),(2,':huh:','huh.gif','huh',2),(3,'^_^','happy.gif','happy',2),(4,':o','ohmy.gif','ohmy',2),(5,';)','wink.gif','wink',2),(6,':P','tongue.gif','tongue',2),(7,':D','biggrin.gif','biggrin',2),(8,':lol:','laugh.gif','laugh',2),(9,'B)','cool.gif','cool',2),(10,':rolleyes:','rolleyes.gif','rolleyes',2),(11,'-_-','sleep.gif','sleep',2),(12,'&lt;_&lt;','dry.gif','dry',2),(13,':)','smile.gif','smile',2),(14,':wub:','wub.gif','wub',2),(15,':angry:','mad.gif','mad',2),(16,':(','sad.gif','sad',2),(17,':unsure:','unsure.gif','unsure',2),(18,':wacko:','wacko.gif','wacko',2),(19,':blink:','blink.gif','blink',2),(20,':ph34r:','ph34r.gif','ph34r',2);
/*!40000 ALTER TABLE `y_sys_smilies` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

