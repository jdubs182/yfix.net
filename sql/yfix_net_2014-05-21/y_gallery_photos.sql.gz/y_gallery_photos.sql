
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `y_gallery_photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `y_gallery_photos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id2` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cat_id` int(10) unsigned NOT NULL DEFAULT '0',
  `folder_id` int(10) unsigned NOT NULL,
  `img_name` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `desc` text NOT NULL,
  `show_in_ads` enum('0','1') NOT NULL DEFAULT '0',
  `diplay_order` int(10) unsigned NOT NULL DEFAULT '0',
  `general_sort_id` int(10) unsigned NOT NULL DEFAULT '0',
  `folder_sort_id` int(10) unsigned NOT NULL DEFAULT '0',
  `add_date` int(10) unsigned NOT NULL DEFAULT '0',
  `other_info` text NOT NULL,
  `active` enum('1','0') NOT NULL DEFAULT '1',
  `is_public` enum('0','1') NOT NULL DEFAULT '0',
  `is_featured` enum('0','1') NOT NULL DEFAULT '0',
  `geo_cc` char(2) NOT NULL,
  `geo_rc` char(2) NOT NULL,
  `priority` int(11) NOT NULL DEFAULT '0',
  `allow_rate` enum('1','0') NOT NULL,
  `rating` float NOT NULL,
  `num_votes` int(10) unsigned NOT NULL,
  `votes_sum` int(11) NOT NULL,
  `last_vote_date` int(10) unsigned NOT NULL,
  `allow_tagging` enum('0','1') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `add_date` (`add_date`),
  KEY `folder_id` (`folder_id`),
  KEY `is_public` (`is_public`),
  KEY `geo_cc` (`geo_cc`),
  KEY `geo_rc` (`geo_rc`),
  KEY `rating` (`rating`),
  KEY `id2` (`id2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `y_gallery_photos` WRITE;
/*!40000 ALTER TABLE `y_gallery_photos` DISABLE KEYS */;
/*!40000 ALTER TABLE `y_gallery_photos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

